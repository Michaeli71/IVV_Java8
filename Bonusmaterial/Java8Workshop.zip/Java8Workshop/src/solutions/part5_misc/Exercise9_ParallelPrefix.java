package solutions.part5_misc;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise9_ParallelPrefix
{
    public static void main(final String[] args) 
    {
        final int[] original = new int[1_000];
        for (int i = 0; i < original.length; i++) 
        {
            original[i] = i + 1;
        }

        sum(original);
        System.out.println("sum: " + original[999]);
        
        final int[] original2 = new int[1_000];

        final IntUnaryOperator fill = idx -> idx + 1;
        Arrays.parallelSetAll(original2, fill);
        
        final IntBinaryOperator sum = (val1, val2) -> val1 + val2;
        Arrays.parallelPrefix(original2, sum);
        System.out.println("sum: " + original2[999]);
    }

    private static void sum(final int[] values) 
    {
        int sum = 0;
        for (int i = 0; i < values.length; i++) 
        {
            values[i] += sum;
            sum = values[i];
        }
    }
}
