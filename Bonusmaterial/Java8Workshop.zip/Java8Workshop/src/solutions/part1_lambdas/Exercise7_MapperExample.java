package solutions.part1_lambdas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise7_MapperExample
{
    public static void main(String[] args)
    {
        final List<String> names = Arrays.asList("Tim", "Andi", "Michael");

        // a)
        final Mapper<String, Integer> intMapper = String::length;
        System.out.println(intMapper.mapAll(names));

        final Mapper<String, String> stringMapper = str -> ">> " + str.toUpperCase() + " <<";
        final List<String> upperCaseNames = stringMapper.mapAll(names);
        System.out.println(upperCaseNames);
                
        // b)
        final Function<String, Integer> intMapperFunc = String::length;
        System.out.println(applyAll(names, intMapperFunc));

        final Function<String, String> stringMapperFunc = str -> ">> " + str.toUpperCase() + " <<";
        final List<String> upperCaseNames2 = applyAll(names, stringMapperFunc);
        System.out.println(upperCaseNames);
    }

    @FunctionalInterface
    public interface Mapper<S, T>
    {
        T map(S elem);

        default public List<T> mapAll(final List<S> sourceElements)
        {
            final List<T> convertedElements = new ArrayList<>();

            for (final S elem : sourceElements)
            {
                final T mappedElem = map(elem);
                convertedElements.add(mappedElem);
            }

            return convertedElements;
        }
    }
    
    // b)
    public static <T,R> List<R>  applyAll(final List<T> sourceElements, final Function<T, R> func)
    {
    		final List<R> result = new ArrayList<>();
    		for (final T elem : sourceElements)
    		{
    			 final R mappedElem = func.apply(elem);
    			 result.add(mappedElem);
    		}
    		return result;	
    }
}
