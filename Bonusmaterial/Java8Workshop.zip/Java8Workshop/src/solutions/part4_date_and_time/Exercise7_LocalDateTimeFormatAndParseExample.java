package solutions.part4_date_and_time;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class Exercise7_LocalDateTimeFormatAndParseExample 
{	
	public static void main(final String[] args) 
	{
		final LocalDateTime jdk9Release = LocalDateTime.of(2017, 7, 27, 13, 14, 15);
		
		final DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd MM yyyy HH");
		final DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm");
		final DateTimeFormatter formatter3 = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
		final DateTimeFormatter formatter4 = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withLocale(Locale.UK);
		
		final DateTimeFormatter[] formatters = {formatter1, formatter2, formatter3, formatter4};
		for (final DateTimeFormatter formatter : formatters)
		{	
			final String formatterDate = formatter.format(jdk9Release);
			System.out.print("Formatted: " + formatterDate);
			System.out.println(" / Parsed: " + LocalDateTime.parse(formatterDate, formatter));
		}
	}
}
