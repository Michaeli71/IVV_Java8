package solutions.part4_date_and_time;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise3_DayOfWeekYear 
{
	public static void main(final String[] args) 
	{
        // a)
	    final LocalDate christmasEve = LocalDate.of(2014, 12, 24);
		System.out.println(DayOfWeek.from(christmasEve));

		// b)
        final LocalDate now = LocalDate.now();
        System.out.println(DayOfWeek.from(now));

        // c)
        final Period period = Period.of(1, 2, 14);
        
		final LocalDate oneWeekBefore = christmasEve.minusWeeks(1);
		System.out.println(oneWeekBefore + " is a " +  DayOfWeek.from(oneWeekBefore));
		final LocalDate periodAfter = christmasEve.plus(period);
		System.out.println(periodAfter + " is a " + DayOfWeek.from(periodAfter));
		
		// d)
		System.out.println(oneWeekBefore + " DoM: " + oneWeekBefore.getDayOfMonth());
		System.out.println(oneWeekBefore + " DoY: " + oneWeekBefore.getDayOfYear());
		System.out.println(periodAfter + " DoM: " + periodAfter.getDayOfMonth());
		System.out.println(periodAfter + " DoY. " + periodAfter.getDayOfYear());
	}
}
