package solutions.part2_bulk_operations;

import java.util.function.Predicate;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise2_Predicate_And_Classes
{
    public static void main(final String[] args)
    {
        final Person tim = new Person("Tim", 43);
        final Person timmy = new Person("Timmy", 17);

        final Predicate<Person> isAdult_V1 = person -> person.getAge() >= 18;
        final Predicate<Person> isAdult_V2 = Person::isAdult;

        System.out.println(isAdult_V2.test(timmy));
        System.out.println(isAdult_V2.test(tim));
    }
}
