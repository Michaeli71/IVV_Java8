package solutions.part3_streams_and_filter_map_reduce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise3_ToArray_ToList
{
	public static void main(String[] args) 
	{
		final String[] namesArray = {"Tim", "Tom", "Andy", "Mike", "Merten"};
		final Stream<String> streamFromArray = Arrays.stream(namesArray);
		final Stream<String> streamFromValues = Stream.of(namesArray);

		final Object[] contentsAsArray = streamFromArray.toArray();
		final List<String> contentsAsList = streamFromValues.collect(Collectors.toList());
		
		System.out.println(Arrays.asList(contentsAsArray));
		System.out.println(contentsAsList);
	}
}
