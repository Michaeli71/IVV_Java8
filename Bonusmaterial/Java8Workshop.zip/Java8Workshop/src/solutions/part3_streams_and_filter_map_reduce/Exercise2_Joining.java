package solutions.part3_streams_and_filter_map_reduce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise2_Joining {

	public static void main(String[] args) 
	{
		final String[] namesArray = {"Tim", "Tom", "Andy", "Mike", "Merten"};
		final List<String> names = Arrays.asList(namesArray);

		names.forEach(str -> System.out.print(str + ", "));
		System.out.println();
		
		// Collectors.joining
		final String joined = names.stream().collect(Collectors.joining(", "));
		System.out.println(joined);
	}
}
